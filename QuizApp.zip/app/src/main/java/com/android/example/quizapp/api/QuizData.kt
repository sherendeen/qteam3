package com.android.example.quizapp.api

import com.google.gson.annotations.SerializedName

data class QuizData (
    @SerializedName("id")
    val id: Int = 0,
    @SerializedName("text")
    val text:String = ""
)