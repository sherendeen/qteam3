package com.android.example.quizapp.api

import com.google.gson.annotations.SerializedName

class ApiResponse {

    lateinit var questions : List<ApiQuestionData>
    lateinit var answers : List<ApiAnswerData>
}