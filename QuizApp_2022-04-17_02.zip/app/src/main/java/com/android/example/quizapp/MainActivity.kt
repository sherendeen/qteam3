package com.android.example.quizapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.android.example.quizapp.api.ApiAnswerData
import com.android.example.quizapp.api.ApiQuestionData
import com.android.example.quizapp.api.MyApiService
import com.android.example.quizapp.databinding.ActivityMainBinding
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import android.content.ContentValues.TAG
import android.util.Log
import com.android.example.quizapp.api.ApiResponse
import com.google.gson.Gson
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {

    val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // remove UI system from
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        setupRetrofit()

        binding.btnStart.setOnClickListener {

            if(binding.etName.text.toString().isEmpty()){
                Toast.makeText(this,"Please enter your name", Toast.LENGTH_SHORT).show()
            }else{
                val intent = Intent(this, QuizQuestionsActivity::class.java)
                intent.putExtra(Constants.USER_NAME, binding.etName.text.toString())
                startActivity(intent)
                finish()
            }
        }

    }

    private fun setupRetrofit() {

        val retrofit = Retrofit.Builder()
            .baseUrl("https://my-json-server.typicode.com/sherendeen/qteam3/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(MyApiService::class.java)

        val callQuestions : Call<List<ApiQuestionData>> = service.getQuestions()

        val callAnswers : Call<List<ApiAnswerData>> = service.getAnswers()

        callQuestions.enqueue(object : Callback<List<ApiQuestionData>> {

            override fun onResponse(
                call: Call<List<ApiQuestionData>>,
                response: Response<List<ApiQuestionData>>
            ) {
                val text = response.body()

                Log.e(TAG, "RESPONSE LOOKS LIKE THIS::: $text ")
                if (text!= null) {
                    var content : String = ""
                    for(i in text) {
                        // data is retrieved here
                        content += "ID: " + i.id.toString() + "\n"
                        content += "Text: " + i.text.toString()
                    }
                    Log.i(TAG, "$content")
                }
            }

            override fun onFailure(call: Call<List<ApiQuestionData>>, t: Throwable) {
                Log.e(TAG, "Epic Failure. (Not owned by Epic)")
            }

        })

        callAnswers.enqueue(object : Callback<List<ApiAnswerData>> {
            override fun onResponse(
                call: Call<List<ApiAnswerData>>,
                response: Response<List<ApiAnswerData>>
            ) {
                val text = response.body()

                Log.e(TAG, "RESPONSE LOOKS LIKE THIS::: $text ")
                if (text!= null) {
                    var content : String = ""
                    for(i in text) {
                        // data is retrieved here
                        content += "ID: " + i.id.toString() + "\n"
                        content += "BODY: " + i.body.toString() + "\n"
                        content += "Is it the correct answer? " + i.is_correct.toString() + "\n"
                        content += "question that for which this answer is in response to: "
                        + i.questionId
                    }
                    Log.i(TAG, "$content")
                }
            }

            override fun onFailure(call: Call<List<ApiAnswerData>>, t: Throwable) {
                Log.e(TAG, "Epic Failure.")
            }

        })

    }
}