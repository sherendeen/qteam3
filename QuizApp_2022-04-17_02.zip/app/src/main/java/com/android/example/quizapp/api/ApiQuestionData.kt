package com.android.example.quizapp.api

import com.google.gson.annotations.SerializedName

data class ApiQuestionData (@SerializedName("id")  val id : Int,
                            @SerializedName("text")
                            val text : String   )
