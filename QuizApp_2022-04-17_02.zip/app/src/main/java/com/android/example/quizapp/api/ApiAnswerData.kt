package com.android.example.quizapp.api

data class ApiAnswerData ( val id : Int,
                           val body : String,
                           val is_correct : Boolean,
                           val questionId : Int )
