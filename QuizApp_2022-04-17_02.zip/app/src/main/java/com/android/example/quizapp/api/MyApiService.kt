package com.android.example.quizapp.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface MyApiService {


    @GET("questions")
    fun getQuestions() : Call<List<ApiQuestionData>>

    @GET("answers")
    fun getAnswers() : Call<List<ApiAnswerData>>


//    @GET("/answers")
//    fun getAnswersByQuestionId() : Call<ApiResponse>

}