package com.android.example.quizapp.API.models

data class Question (val questionText : String, val questionId : Int)
