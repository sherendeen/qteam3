package com.android.example.quizapp.API

import com.android.example.quizapp.API.models.Quiz
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET("/")
    fun getQuiz(result : String) : Call<Quiz>

}