package com.android.example.quizapp.API.models

data class Quiz(val quizName : String,
                val questions : ArrayList<Question>,
                val answers : ArrayList<Answer>)
