package com.android.example.quizapp.API

class ServiceFetcher {
}