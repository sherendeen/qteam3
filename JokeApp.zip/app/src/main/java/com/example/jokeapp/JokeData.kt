package com.example.jokeapp

import com.google.gson.annotations.SerializedName

data class JokeData (
//    @SerializedName("programming")
//    val programming: String = "",
//    @SerializedName("id")
//    val id: Int = 0,
    @SerializedName("joke")
    val joke: String = ""
)