package com.android.example.quizapp.common

// global
var questions : ArrayList<QuestionMk2> = ArrayList<QuestionMk2>()

class QuestionMk2(var qid: Int, var questionText : String,  var answers:ArrayList<Answer>?) {

    fun getCorrectAnswer() : Answer? {
        if (answers != null) {
            for (answer in answers!!) {
                if (answer.isCorrect) {
                    return answer
                }
            }
        }
        return null
    }

}

data class Answer (var id:Int, var answerText:String, var isCorrect:Boolean )